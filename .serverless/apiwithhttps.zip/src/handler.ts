//This file is AWS Lambda entry point
import { Context, Handler } from 'aws-lambda';
import { createServer, proxy } from 'aws-serverless-express';

import awsServerlessExpress from 'aws-serverless-express';
import awsServerlessExpressMiddleware from 'aws-serverless-express/middleware';
import { configureApp } from '../index';

// const app = require('./index.ts')

const app = configureApp();



// app.use(awsServerlessExpressMiddleware.eventContext());

// const server = awsServerlessExpress.createServer(app);

// exports.serverlessEntry = (event:any, context:any) => awsServerlessExpress.proxy(server, event, context);

const binaryMimeTypes: string[] = [
    // 'application/javascript',
    'application/json',
    // 'application/octet-stream',
    // 'application/xml',
    // 'font/eot',
    // 'font/opentype',
    // 'font/otf',
    // 'image/jpeg',
    // 'image/png',
    // 'image/svg+xml',
    // 'text/comma-separated-values',
    // 'text/css',
    // 'text/html',
    // 'text/javascript',
    // 'text/plain',
    // 'text/text',
    // 'text/xml',
  ];
  const server = createServer(app, undefined, binaryMimeTypes);
  
  export const apiwithhttps = (event: any, context: Context) =>
    proxy(server, event, context);