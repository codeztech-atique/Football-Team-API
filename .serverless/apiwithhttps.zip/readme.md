npm install -g typescript

npm install -D @types/express @types/node nodemon ts-node typescript

tsc --init