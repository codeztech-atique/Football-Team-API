
//'use strict'
//This file is AWS Lambda entry point

import { configureApp } from './index';
const awsServerlessExpress = require('aws-serverless-express')

const app = configureApp();
const server = awsServerlessExpress.createServer(app);

exports.apiwithhttps = (event: any, context: any) => {
    awsServerlessExpress.proxy(server, event, context)
}

